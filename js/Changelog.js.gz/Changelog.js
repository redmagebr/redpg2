// This is a typescript file, but it's not to be written as typescript
// Only Changelog class usage is allowed in this file.
var change;
change = new Changelog(0, 9, 0);

Changelog.finished();